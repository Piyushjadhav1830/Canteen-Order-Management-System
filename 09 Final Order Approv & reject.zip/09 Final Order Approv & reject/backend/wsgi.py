"""
wsgi.py — Production entry point for Gunicorn
Usage: gunicorn -w 4 -b 0.0.0.0:48000 wsgi:app
"""
import sys
import os

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(CURRENT_DIR)

if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from app import app

if __name__ == '__main__':
    app.run()
