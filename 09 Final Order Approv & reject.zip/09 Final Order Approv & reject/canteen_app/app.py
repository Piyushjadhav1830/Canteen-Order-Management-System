from flask import Blueprint, render_template, request, jsonify, session, redirect, url_for

canteen_app = Blueprint(
    'canteen_app',
    __name__,
    template_folder='templates',
    static_folder='static'
)

DEFAULT_CANTEEN = {
    'id': 1,
    'username': 'Canteen Manager'
}

def login_required(f):
    def wrapper(*args, **kwargs):
        if 'user' not in session or session.get('user_type') != 'canteen':
            return redirect(url_for('.login'))
        return f(*args, **kwargs)
    wrapper.__name__ = f.__name__
    return wrapper

@canteen_app.route('/login')
def login():
    if 'user' in session and session.get('user_type') == 'canteen':
        return redirect(url_for('canteen_app.dashboard'))
    return render_template('login.html')

@canteen_app.route('/')
def index():
    return redirect(url_for('canteen_app.dashboard'))

@canteen_app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html', user=session['user'])

@canteen_app.route('/orders')
@login_required
def orders():
    return render_template('orders.html', user=session['user'])

@canteen_app.route('/order/<int:order_id>')
@login_required
def order_detail(order_id):
    return render_template('order_detail.html', user=session['user'], order_id=order_id)

@canteen_app.route('/logout')
def logout():
    session.pop('user', None)
    session.pop('user_type', None)
    session.pop('reviewer_auth_expires_at', None)
    return redirect(url_for('canteen_app.login'))

@canteen_app.route('/ping')
def ping():
    if 'user' in session and session.get('user_type') == 'canteen':
        return jsonify({'alive': True, 'user': session['user']['username']})
    return jsonify({'alive': True})
