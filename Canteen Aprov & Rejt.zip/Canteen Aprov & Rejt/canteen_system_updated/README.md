# 🏭 Tata Motors Canteen Order Management System

## Two Separate Web Applications

| App | Port | Login |
|-----|------|-------|
| 🏢 **Supervisor Portal** | `localhost:5000` | supervisor@tata.com / pass123 |
| 🍽️ **Canteen Dashboard** | `localhost:5001` | canteen / canteen123 |
| ⚙️ **Backend API** | `localhost:5002` | Internal only |

---

## Quick Start

### Option 1: Run All at Once
```bash
bash start_all.sh
```

### Option 2: Run Individually
```bash
# Terminal 1 - Backend API
cd backend && python app.py

# Terminal 2 - Supervisor App
cd supervisor_app && python app.py

# Terminal 3 - Canteen App
cd canteen_app && python app.py
```

### Install Dependencies
```bash
pip install flask flask-cors
```

---

## System Architecture

```
canteen_system/
├── backend/
│   ├── app.py          ← REST API (port 5002)
│   └── database.py     ← SQLite database
├── supervisor_app/
│   ├── app.py          ← Supervisor Flask app (port 5000)
│   └── templates/
│       ├── base.html
│       ├── login.html
│       ├── register.html
│       ├── dashboard.html
│       ├── new_order.html
│       ├── order_history.html
│       └── order_detail.html
├── canteen_app/
│   ├── app.py          ← Canteen Flask app (port 5001)
│   └── templates/
│       ├── base.html
│       ├── login.html
│       ├── dashboard.html
│       ├── orders.html
│       └── order_detail.html
└── start_all.sh
```

---

## Features

### Supervisor Portal (localhost:5000)
- 🔐 Login & Registration
- 📊 Dashboard with order stats
- 🍽️ Place new orders with quick-add items
- 📋 View and filter order history
- 🔍 Track individual order status
- Auto-refresh for pending orders

### Canteen Dashboard (localhost:5001)
- 🔐 Separate login system
- 📊 KPI cards (Total, Pending, Approved, Rejected, Partial)
- 📋 Order management with search/filter
- ✅ Full order approval
- ❌ Full order rejection with reason
- ⚡ Item-level partial approval
- 🔄 Auto-refresh every 30 seconds

---

## Tech Stack
- **Backend**: Python Flask + SQLite + REST API
- **Frontend**: HTML, CSS, JavaScript (vanilla)
- **Architecture**: Two separate Flask apps sharing one SQLite database
- **Design**: Corporate premium blue (Supervisor) + Dark teal admin (Canteen)
