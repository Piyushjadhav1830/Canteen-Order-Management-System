import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), 'canteen.db')

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS supervisors (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        department TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS canteen_users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        email TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    supervisor_id INTEGER,
    supervisor_name TEXT NOT NULL,
    supervisor_email TEXT NOT NULL,
    department TEXT NOT NULL,
    shop_name TEXT NOT NULL,
    shift TEXT NOT NULL,
    people_count INTEGER NOT NULL,
    delivery_date TEXT,
    delivery_time TEXT,
    status TEXT DEFAULT 'Pending',
    canteen_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (supervisor_id) REFERENCES supervisors(id)
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS order_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL,
        item_name TEXT NOT NULL,
        quantity INTEGER NOT NULL,
        unit TEXT DEFAULT 'units',
        status TEXT DEFAULT 'Pending',
        rejection_reason TEXT,
        FOREIGN KEY (order_id) REFERENCES orders(id)
    )''')
    # Default accounts
    c.execute("INSERT OR IGNORE INTO supervisors (name, email, password, department) VALUES ('Admin Supervisor', 'supervisor@tata.com', 'pass123', 'General')")
    c.execute("INSERT OR IGNORE INTO canteen_users (username, password, email) VALUES ('canteen', 'canteen123', 'canteen@tata.com')")
    conn.commit()
    conn.close()
