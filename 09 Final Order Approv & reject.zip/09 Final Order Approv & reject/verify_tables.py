#!/usr/bin/env python3
"""Verify database tables were created"""

import sqlite3
import os

db_path = 'backend/canteen.db'

if os.path.exists(db_path):
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    c.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
    tables = [row[0] for row in c.fetchall()]
    conn.close()
    
    print("=" * 50)
    print(f"✓ Database: {db_path}")
    print("=" * 50)
    print(f"Tables created: {len(tables)}")
    for table in tables:
        c = sqlite3.connect(db_path).cursor()
        c.execute(f"SELECT COUNT(*) FROM {table}")
        count = c.fetchone()[0]
        print(f"  ✓ {table} ({count} rows)")
    print("=" * 50)
else:
    print(f"✗ Database not found: {db_path}")
