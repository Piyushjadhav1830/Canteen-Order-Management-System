from flask import Flask, render_template, session, redirect, url_for, request, jsonify
from datetime import timedelta
import os

app = Flask(__name__)
app.secret_key = 'supervisor_secret_key_tata_2024'
app.permanent_session_lifetime = timedelta(days=7)  # Session lasts 7 days

API_BASE = 'http://localhost:5002/api'

@app.route('/')
def index():
    if 'supervisor' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login')
def login():
    # If already logged in, go to dashboard
    if 'supervisor' in session:
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/register')
def register():
    return render_template('register.html')

@app.route('/dashboard')
def dashboard():
    if 'supervisor' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html', supervisor=session['supervisor'])

@app.route('/new-order')
def new_order():
    if 'supervisor' not in session:
        return redirect(url_for('login'))
    return render_template('new_order.html', supervisor=session['supervisor'])

@app.route('/order-history')
def order_history():
    if 'supervisor' not in session:
        return redirect(url_for('login'))
    return render_template('order_history.html', supervisor=session['supervisor'])

@app.route('/order/<int:order_id>')
def order_detail(order_id):
    if 'supervisor' not in session:
        return redirect(url_for('login'))
    return render_template('order_detail.html', supervisor=session['supervisor'], order_id=order_id)

@app.route('/set-session', methods=['POST'])
def set_session():
    data = request.json
    session.permanent = True  # Make session persistent
    session['supervisor'] = data
    return jsonify({'success': True})

@app.route('/ping')
def ping():
    """Keepalive endpoint — refreshes session without redirect."""
    if 'supervisor' in session:
        session.modified = True  # Touch the session to reset expiry
        return jsonify({'alive': True, 'user': session['supervisor'].get('name', '')})
    return jsonify({'alive': False}), 401

@app.route('/logout')
def logout():
    session.pop('supervisor', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(port=5000, debug=True)
