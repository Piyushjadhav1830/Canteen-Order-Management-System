#!/bin/bash
# Tata Motors Canteen System - Start All Services

echo "======================================================"
echo "  TATA MOTORS CANTEEN ORDER MANAGEMENT SYSTEM"
echo "======================================================"
echo ""
echo "Installing dependencies..."
pip install flask flask-cors mysql-connector-python pyodbc --break-system-packages -q

echo ""
echo "Starting Backend API on port 48000..."
cd "$(dirname "$0")/backend"
python app.py &
BACKEND_PID=$!
sleep 2

echo ""
echo "======================================================"
echo "  ALL SERVICES RUNNING!"
echo "======================================================"
echo ""
echo "  ⚙️  Backend API (Supervisor + Canteen UI)"
echo "      → http://localhost:48000"
echo ""
echo "  🏢 Supervisor Portal  → http://localhost:48000/supervisor"
echo ""
echo "  🍽️  Canteen Dashboard  → http://localhost:48000/canteen"
echo ""
echo "  Press Ctrl+C to stop all services"
echo "======================================================"

wait $BACKEND_PID
