#!/usr/bin/env python3
"""
debug_mysql.py
Check MySQL connectivity with detailed error reporting
"""

import mysql.connector
import time
import socket

print("=" * 60)
print("  MySQL Connection Debug")
print("=" * 60)
print()

# Test 1: Check if port is open
print("1. Testing port connectivity...")
try:
    sock = socket.create_connection(("127.0.0.1", 3306), timeout=3)
    print("   ✓ Port 3306 is open")
    sock.close()
except Exception as e:
    print(f"   ✗ Cannot reach port 3306: {e}")

print()

# Test 2: Try to connect with different configurations
configs = [
    {'host': '127.0.0.1', 'user': 'root', 'password': 'admin123'},
    {'host': 'localhost', 'user': 'root', 'password': 'admin123'},
    {'host': 'localhost', 'user': 'root', 'password': ''},
]

for i, config in enumerate(configs, 1):
    print(f"2.{i} Trying: {config['host']}@{config['user']} (pass: {config['password'] or 'empty'})")
    try:
        conn = mysql.connector.connect(**config, connection_timeout=5)
        print(f"     ✓ Success!")
        cursor = conn.cursor()
        cursor.execute("SELECT VERSION()")
        version = cursor.fetchone()[0]
        print(f"     MySQL version: {version}")
        cursor.close()
        conn.close()
        break
    except Exception as e:
        print(f"     ✗ Error: {str(e)[:80]}")

print()
print("=" * 60)
