from flask import Flask, request, jsonify
import os
import sys
import threading
from datetime import datetime, timezone

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(CURRENT_DIR)

if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from database import get_db, init_db
from email_utils import send_order_received, send_order_status_update
from canteen_app.app import canteen_app
from supervisor_app.app import supervisor_app

COMMON_STATIC = os.path.join(PROJECT_ROOT, 'canteen_app', 'static')
app = Flask(__name__, static_folder=COMMON_STATIC, static_url_path='/static')

app.register_blueprint(canteen_app, url_prefix='/canteen')
app.register_blueprint(supervisor_app, url_prefix='/supervisor')


def _parse_created_at(raw_value):
    if not raw_value:
        return None
    try:
        dt = datetime.fromisoformat(str(raw_value).replace(' ', 'T'))
        return dt.replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def _with_order_timing(order_dict):
    if order_dict.get('status') == 'Pending':
        created_at = _parse_created_at(order_dict.get('created_at'))
        if created_at:
            now_utc = datetime.utcnow().replace(tzinfo=timezone.utc)
            pending_minutes = max(int((now_utc - created_at).total_seconds() // 60), 0)
        else:
            pending_minutes = 0
    else:
        pending_minutes = 0

    order_dict['pending_minutes'] = pending_minutes
    order_dict['overdue'] = order_dict.get('status') == 'Pending' and pending_minutes >= 60
    return order_dict


def _get_items_for_orders(conn, order_ids):
    if not order_ids:
        return {}

    placeholders = ','.join('?' for _ in order_ids)
    rows = conn.execute(
        f'''SELECT id, order_id, item_name, quantity, unit, status, rejection_reason
            FROM order_items
            WHERE order_id IN ({placeholders})
            ORDER BY id''',
        order_ids,
    ).fetchall()

    grouped = {oid: [] for oid in order_ids}
    for row in rows:
        item = dict(row)
        grouped[item['order_id']].append(item)
    return grouped


def _get_order_by_id(conn, order_id):
    order = conn.execute('SELECT * FROM orders WHERE id=?', (order_id,)).fetchone()
    if not order:
        return None

    order_dict = dict(order)
    items = conn.execute(
        '''SELECT id, order_id, item_name, quantity, unit, status, rejection_reason
           FROM order_items WHERE order_id=? ORDER BY id''',
        (order_id,),
    ).fetchall()
    order_dict['items'] = [dict(item) for item in items]
    return _with_order_timing(order_dict)


def _send_status_email_async(to_email, supervisor_name, order_id, status, notes, items):
    def _send():
        send_order_status_update(to_email, supervisor_name, order_id, status, notes, items)

    threading.Thread(target=_send, daemon=True).start()

@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    return response

@app.route('/', defaults={'path': ''}, methods=['OPTIONS'])
@app.route('/<path:path>', methods=['OPTIONS'])
def handle_options(path):
    return jsonify({}), 200


init_db()


@app.route('/')
def home():
    return '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tata Motors Canteen System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            width: 100%;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            backdrop-filter: blur(10px);
        }

        .header {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 40px 30px;
            text-align: center;
        }

        .header h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            font-weight: 700;
        }

        .header p {
            font-size: 1.1rem;
            opacity: 0.9;
        }

        .content {
            padding: 40px 30px;
        }

        .cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
            margin-top: 30px;
        }

        .card {
            background: white;
            border-radius: 15px;
            padding: 30px 25px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            border: 2px solid transparent;
            cursor: pointer;
            text-decoration: none;
            color: inherit;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
            border-color: #667eea;
        }

        .card-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            margin: 0 auto 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }

        .card.supervisor .card-icon {
            background: linear-gradient(135deg, #ff6b6b, #ee5a24);
        }

        .card.canteen .card-icon {
            background: linear-gradient(135deg, #4ecdc4, #44a08d);
        }

        .card.api .card-icon {
            background: linear-gradient(135deg, #a8e6cf, #52c234);
        }

        .card h3 {
            font-size: 1.4rem;
            margin-bottom: 10px;
            color: #333;
            font-weight: 600;
        }

        .card p {
            color: #666;
            font-size: 0.95rem;
            line-height: 1.5;
        }

        .status {
            display: inline-block;
            padding: 8px 16px;
            background: linear-gradient(135deg, #52c234, #4ecdc4);
            color: white;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
            margin-top: 20px;
        }

        .footer {
            text-align: center;
            padding: 20px 30px;
            background: #f8f9fa;
            border-top: 1px solid #e9ecef;
            color: #6c757d;
            font-size: 0.9rem;
        }

        @media (max-width: 768px) {
            .header h1 {
                font-size: 2rem;
            }

            .cards-grid {
                grid-template-columns: 1fr;
            }

            .card {
                padding: 25px 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🍽️ Tata Motors Canteen System</h1>
            <p>Streamlined Food Ordering & Management Platform</p>
        </div>

        <div class="content">
            <div class="status">✅ System Running</div>

            <div class="cards-grid">
                <a href="/supervisor" class="card supervisor">
                    <div class="card-icon">👔</div>
                    <h3>Supervisor Portal</h3>
                    <p>Place orders, track deliveries, and manage department requirements for your team.</p>
                </a>

                <a href="/canteen" class="card canteen">
                    <div class="card-icon">🏪</div>
                    <h3>Canteen Dashboard</h3>
                    <p>Manage orders, update status, process deliveries, and handle customer requests.</p>
                </a>

                <a href="/api" class="card api">
                    <div class="card-icon">🔌</div>
                    <h3>API Documentation</h3>
                    <p>Access REST API endpoints for integration, authentication, and data management.</p>
                </a>
            </div>
        </div>

        <div class="footer">
            <p>© 2026 Tata Motors Canteen System | Built with Flask & SQLite</p>
        </div>
    </div>
</body>
</html>
'''


@app.route('/api/supervisor/login', methods=['POST'])
def supervisor_login():
    data = request.json or {}
    conn = get_db()
    user = conn.execute(
        'SELECT * FROM supervisors WHERE email=? AND password=?',
        (data.get('email'), data.get('password')),
    ).fetchone()
    conn.close()

    if user:
        return jsonify(
            {
                'success': True,
                'id': user['id'],
                'name': user['name'],
                'email': user['email'],
                'department': user['department'],
            }
        )

    return jsonify({'success': False, 'message': 'Invalid credentials'}), 401


@app.route('/api/supervisor/register', methods=['POST'])
def supervisor_register():
    data = request.json or {}
    conn = get_db()

    try:
        conn.execute(
            'INSERT INTO supervisors (name, email, password, department) VALUES (?,?,?,?)',
            (data['name'], data['email'], data['password'], data.get('department', '')),
        )
        conn.commit()
        return jsonify({'success': True})
    except Exception:
        return jsonify({'success': False, 'message': 'Email already exists'}), 400
    finally:
        conn.close()


@app.route('/api/canteen/login', methods=['POST'])
def canteen_login():
    data = request.json or {}
    conn = get_db()
    user = conn.execute(
        'SELECT * FROM canteen_users WHERE username=? AND password=?',
        (data.get('username'), data.get('password')),
    ).fetchone()
    conn.close()

    if user:
        return jsonify(
            {
                'success': True,
                'id': user['id'],
                'username': user['username'],
                'email': user['email'],
            }
        )

    return jsonify({'success': False, 'message': 'Invalid credentials'}), 401


@app.route('/api/orders', methods=['POST'])
def create_order():
    data = request.json or {}
    required_fields = [
        'supervisor_name',
        'supervisor_email',
        'department',
        'shop_name',
        'shift',
        'people_count',
    ]

    missing = [field for field in required_fields if not data.get(field)]
    if missing:
        return jsonify({'success': False, 'error': f"Missing fields: {', '.join(missing)}"}), 400

    conn = get_db()
    # insert order and obtain new id; some sqlite setups can return None on
    # lastrowid if the connection was reused or type mismatch, so we fall back to
    # querying the current maximum id afterwards.
    cur = conn.execute(
        '''INSERT INTO orders
        (supervisor_id, supervisor_name, supervisor_email, department,
         shop_name, shift, people_count, delivery_date, delivery_time)
        VALUES (?,?,?,?,?,?,?,?,?)''',
        (
            data.get('supervisor_id'),
            data['supervisor_name'],
            data['supervisor_email'],
            data['department'],
            data['shop_name'],
            data['shift'],
            data['people_count'],
            data.get('delivery_date'),
            data.get('delivery_time'),
        ),
    )

    order_id = cur.lastrowid
    if not order_id:
        row = conn.execute('SELECT MAX(id) AS mid FROM orders').fetchone()
        order_id = row['mid'] if row else None
    print(f"[DEBUG] Created order id={order_id}")
    items = data.get('items', [])

    for item in items:
        conn.execute(
            'INSERT INTO order_items (order_id,item_name,quantity,unit) VALUES (?,?,?,?)',
            (order_id, item['name'], item['quantity'], item.get('unit', 'units')),
        )

    conn.commit()
    conn.close()

    def _send_received_email():
        send_order_received(
            data['supervisor_email'],
            data['supervisor_name'],
            order_id,
            data['department'],
            data['shop_name'],
            data['shift'],
            data['people_count'],
            items,
            data.get('delivery_time'),
            data.get('delivery_date'),
        )

    threading.Thread(target=_send_received_email, daemon=True).start()

    return jsonify({'success': True, 'order_id': order_id})


@app.route('/api/orders', methods=['GET'])
def get_orders():
    conn = get_db()

    status = request.args.get('status')
    shift = request.args.get('shift')
    date = request.args.get('date')
    search = request.args.get('search')
    supervisor_id = request.args.get('supervisor_id')

    query = 'SELECT * FROM orders WHERE 1=1'
    params = []

    if status:
        query += ' AND status=?'
        params.append(status)
    if shift:
        query += ' AND shift=?'
        params.append(shift)
    if date:
        query += ' AND DATE(created_at)=?'
        params.append(date)
    if search:
        query += ' AND (supervisor_name LIKE ? OR department LIKE ? OR shop_name LIKE ? OR CAST(id AS TEXT) LIKE ?)'
        like_search = f'%{search}%'
        params.extend([like_search, like_search, like_search, like_search])
    if supervisor_id:
        query += ' AND supervisor_id=?'
        params.append(supervisor_id)

    query += ' ORDER BY created_at DESC'

    rows = conn.execute(query, params).fetchall()
    orders = [dict(r) for r in rows]

    order_ids = [order['id'] for order in orders]
    items_map = _get_items_for_orders(conn, order_ids)

    for order in orders:
        order['items'] = items_map.get(order['id'], [])
        _with_order_timing(order)

    conn.close()
    return jsonify(orders)


@app.route('/api/orders/<int:order_id>', methods=['GET'])
def get_order(order_id):
    conn = get_db()
    order = _get_order_by_id(conn, order_id)
    conn.close()

    if not order:
        return jsonify({'success': False, 'error': 'Order not found'}), 404

    return jsonify(order)


@app.route('/api/orders/<int:order_id>/approve', methods=['POST'])
def approve_order(order_id):
    data = request.json or {}
    notes = (data.get('notes') or '').strip()

    conn = get_db()
    order = conn.execute('SELECT * FROM orders WHERE id=?', (order_id,)).fetchone()
    if not order:
        conn.close()
        return jsonify({'success': False, 'error': 'Order not found'}), 404

    conn.execute(
        "UPDATE orders SET status='Approved', canteen_notes=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
        (notes, order_id),
    )
    conn.execute(
        "UPDATE order_items SET status='Approved', rejection_reason=NULL WHERE order_id=?",
        (order_id,),
    )
    conn.commit()

    order_payload = _get_order_by_id(conn, order_id)
    conn.close()

    _send_status_email_async(
        order['supervisor_email'],
        order['supervisor_name'],
        order_id,
        'Approved',
        notes,
        order_payload['items'],
    )

    return jsonify({'success': True})


@app.route('/api/orders/<int:order_id>/reject', methods=['POST'])
def reject_order(order_id):
    data = request.json or {}
    notes = (data.get('notes') or '').strip()

    if not notes:
        return jsonify({'success': False, 'error': 'Rejection reason is required'}), 400

    conn = get_db()
    order = conn.execute('SELECT * FROM orders WHERE id=?', (order_id,)).fetchone()
    if not order:
        conn.close()
        return jsonify({'success': False, 'error': 'Order not found'}), 404

    conn.execute(
        "UPDATE orders SET status='Rejected', canteen_notes=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
        (notes, order_id),
    )
    conn.execute(
        "UPDATE order_items SET status='Rejected', rejection_reason=? WHERE order_id=?",
        (notes, order_id),
    )
    conn.commit()

    order_payload = _get_order_by_id(conn, order_id)
    conn.close()

    _send_status_email_async(
        order['supervisor_email'],
        order['supervisor_name'],
        order_id,
        'Rejected',
        notes,
        order_payload['items'],
    )

    return jsonify({'success': True})


@app.route('/api/orders/<int:order_id>/partial', methods=['POST'])
def partial_review(order_id):
    data = request.json or {}
    updates = data.get('items') or []
    notes = (data.get('notes') or '').strip()

    if not isinstance(updates, list) or not updates:
        return jsonify({'success': False, 'error': 'No item updates provided'}), 400

    conn = get_db()
    order = conn.execute('SELECT * FROM orders WHERE id=?', (order_id,)).fetchone()
    if not order:
        conn.close()
        return jsonify({'success': False, 'error': 'Order not found'}), 404

    valid_statuses = {'Approved', 'Cancelled', 'Substituted'}

    for entry in updates:
        item_id = entry.get('id')
        status = entry.get('status')
        reason = (entry.get('reason') or '').strip()
        alt_item = (entry.get('alt_item') or '').strip()

        if status not in valid_statuses:
            conn.close()
            return jsonify({'success': False, 'error': f'Invalid status for item {item_id}'}), 400

        rejection_reason = None
        if status == 'Cancelled':
            if not reason:
                conn.close()
                return jsonify({'success': False, 'error': f'Cancellation reason required for item {item_id}'}), 400
            rejection_reason = reason
        elif status == 'Substituted':
            if not alt_item:
                conn.close()
                return jsonify({'success': False, 'error': f'Alternative item required for item {item_id}'}), 400
            rejection_reason = f'[ALT:{alt_item}] {reason}'.strip()

        conn.execute(
            'UPDATE order_items SET status=?, rejection_reason=? WHERE id=? AND order_id=?',
            (status, rejection_reason, item_id, order_id),
        )

    item_rows = conn.execute('SELECT status FROM order_items WHERE order_id=?', (order_id,)).fetchall()
    item_statuses = [row['status'] for row in item_rows]

    approved_like = sum(1 for s in item_statuses if s in {'Approved', 'Substituted'})
    cancelled_count = sum(1 for s in item_statuses if s == 'Cancelled')
    substituted_count = sum(1 for s in item_statuses if s == 'Substituted')

    if approved_like == 0:
        final_status = 'Rejected'
    else:
        final_status = 'Approved'

    conn.execute(
        'UPDATE orders SET status=?, canteen_notes=?, updated_at=CURRENT_TIMESTAMP WHERE id=?',
        (final_status, notes, order_id),
    )

    conn.commit()
    order_payload = _get_order_by_id(conn, order_id)
    conn.close()

    _send_status_email_async(
        order['supervisor_email'],
        order['supervisor_name'],
        order_id,
        final_status,
        notes,
        order_payload['items'],
    )

    return jsonify(
        {
            'success': True,
            'final_status': final_status,
            'approved': approved_like,
            'cancelled': cancelled_count,
            'substituted': substituted_count,
        }
    )


@app.route('/api/stats', methods=['GET'])
def get_stats():
    conn = get_db()

    total = conn.execute('SELECT COUNT(*) FROM orders').fetchone()[0]
    pending = conn.execute("SELECT COUNT(*) FROM orders WHERE status='Pending'").fetchone()[0]
    approved = conn.execute("SELECT COUNT(*) FROM orders WHERE status='Approved'").fetchone()[0]
    rejected = conn.execute("SELECT COUNT(*) FROM orders WHERE status='Rejected'").fetchone()[0]
    cancelled = conn.execute("SELECT COUNT(*) FROM orders WHERE status='Cancelled'").fetchone()[0]

    overdue = conn.execute(
        """
        SELECT COUNT(*)
        FROM orders
        WHERE status='Pending'
          AND (strftime('%s','now') - strftime('%s', created_at)) >= 3600
        """
    ).fetchone()[0]

    conn.close()

    return jsonify(
        {
            'total': total,
            'pending': pending,
            'approved': approved,
            'rejected': rejected,
            'cancelled': cancelled,
            'overdue': overdue,
        }
    )


if __name__ == '__main__':
    port = int(os.environ.get('PORT', '48000'))
    app.run(host='0.0.0.0', port=port, debug=True)
