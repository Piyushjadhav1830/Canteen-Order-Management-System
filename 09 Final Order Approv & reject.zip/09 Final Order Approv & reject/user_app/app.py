from flask import Blueprint, render_template

user_app = Blueprint(
    'user_app',
    __name__,
    template_folder='templates',
    static_folder='static'
)

@user_app.route('/')
def index():
    return render_template('order.html')

@user_app.route('/ping')
def ping():
    return {'status': 'ok'}
