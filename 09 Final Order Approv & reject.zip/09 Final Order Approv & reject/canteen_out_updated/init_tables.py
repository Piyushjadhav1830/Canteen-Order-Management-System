#!/usr/bin/env python3
"""
init_tables.py - For canteen_out_updated project
--------------
Simple script to initialize database tables.

Usage:
  python init_tables.py
"""

import os
import sys

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
BACKEND_DIR = os.path.join(CURRENT_DIR, 'backend')

if BACKEND_DIR not in sys.path:
    sys.path.insert(0, BACKEND_DIR)

try:
    from database import init_db
    
    print("=" * 60)
    print("  Database Table Initialization (canteen_out_updated)")
    print("=" * 60)
    print()
    
    print("Creating tables...")
    init_db()
    
    print()
    print("=" * 60)
    print("✅ All tables created successfully!")
    print("=" * 60)
    print()
    print("Tables created:")
    print("  • supervisors")
    print("  • canteen_users")
    print("  • orders")
    print("  • order_items")
    print()
    print("Default users seeded:")
    print("  • Supervisor: supervisor@tata.com / pass123")
    print("  • Canteen User: canteen / canteen123")
    print()
    
except Exception as e:
    print()
    print("❌ Error:", str(e))
    sys.exit(1)
