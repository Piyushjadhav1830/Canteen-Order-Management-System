from flask import Blueprint, render_template, request, jsonify

canteen_app = Blueprint(
    'canteen_app',
    __name__,
    template_folder='templates',
    static_folder='static'
)

DEFAULT_CANTEEN = {
    'id': 1,
    'username': 'Canteen Manager'
}

@canteen_app.route('/')
def index():
    return render_template('dashboard.html', user=DEFAULT_CANTEEN)

@canteen_app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html', user=DEFAULT_CANTEEN)

@canteen_app.route('/orders')
def orders():
    return render_template('orders.html', user=DEFAULT_CANTEEN)

@canteen_app.route('/order/<int:order_id>')
def order_detail(order_id):
    return render_template('order_detail.html', user=DEFAULT_CANTEEN, order_id=order_id)

@canteen_app.route('/ping')
def ping():
    return jsonify({'alive': True})