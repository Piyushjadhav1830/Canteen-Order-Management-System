# MySQL Connection Troubleshooting Guide

## Status Summary

✅ **Database Tables Created Successfully!**
- Main project (`canteen_final`): Tables created in SQLite
- Updated project (`canteen_out_updated`): Tables created in SQLite
- Both projects have data seeded and are operational

### Current Database Status

**canteen_final/backend/canteen.db:**
- supervisors: 1 row
- canteen_users: 1 row  
- orders: 21 rows
- order_items: 37 rows

**canteen_out_updated/backend/canteen.db:**
- supervisors: 1 row
- canteen_users: 1 row
- orders: 20 rows
- order_items: 36 rows

---

## Issue: MySQL Connection Refused

**Current Status:** SQLite is being used as temporary fallback while MySQL connectivity is resolved.

### Problem Symptoms
- Error: "Can't connect to MySQL server on 'localhost:3306' (Errno 10061)"
- MySQL80 service shows as "Running" but connections are refused
- Port 3306 unable to accept connections

### Solution Steps

#### Option 1: Reset MySQL (Recommended for Fresh Start)

**Step 1: Uninstall MySQL Service**
```powershell
# Run as Administrator
"C:\Program Files\MySQL\MySQL Server 8.0\bin\mysqld" --remove MySQL80
```

**Step 2: Delete MySQL Data Directory**
```powershell
# Backup first if you have important data
Remove-Item "C:\ProgramData\MySQL\" -Recurse -Force
```

**Step 3: Reinstall MySQL**
- Download MySQL Community Server: https://dev.mysql.com/downloads/mysql/
- Run installer
- Choose "Server only" if you just need the database
- Keep default port 3306
- When asked for MySQL root password, set it to: **admin123**
- Complete installation

**Step 4: Verify Installation**
```powershell
Get-Service MySQL80
```

**Step 5: Test Connection**
```powershell
python debug_mysql.py
```
Should show successful connections.

---

#### Option 2: Check MySQL Configuration (if reinstall not desired)

**Check MySQL Config File:**
```powershell
"C:\ProgramData\MySQL\MySQL Server 8.0\my.ini"
```

Look for:
```ini
[mysqld]
port=3306
bind-address=127.0.0.1
```

If missing, add them manually.

**Restart MySQL Service:**
```powershell
# Run as Administrator
Restart-Service MySQL80
Start-Sleep -Seconds 3
Get-Service MySQL80
```

---

## Switching from SQLite to MySQL (After Fixing Connection)

Once MySQL is working, update the `.env` files:

**backend/.env:**
```
# MySQL Configuration for canteen_db
DB_HOST=127.0.0.1
DB_PORT=3306
DB_NAME=canteen_db
DB_USER=root
DB_PASSWORD=admin123

# Switch to MySQL
USE_SQLITE=false
PORT=48000
```

**canteen_out_updated/backend/.env:**
Same as above.

---

## Migrate Data from SQLite to MySQL

Once MySQL is working and configured:

**Step 1: Create MySQL Database**
```powershell
python setup_database.py
```

Or manually:
```powershell
python -m mysql.connector.cmd
# connect -h localhost -u root -padmin123
# CREATE DATABASE canteen_db CHARACTER SET utf8mb4;
```

**Step 2: Migrate Data**
```powershell
# Main project
cd canteen_final
python migrate_to_mysql.py

# Updated project  
cd canteen_out_updated
python migrate_to_mysql.py
```

**Step 3: Verify Migration**
```powershell
# Check tables exist in MySQL
mysql -h 127.0.0.1 -u root -padmin123 canteen_db -e "SHOW TABLES;"

# Check data count
mysql -h 127.0.0.1 -u root -padmin123 canteen_db -e "SELECT COUNT(*) FROM orders;"
```

---

## Current Configuration

**Files Created:**
- ✓ `backend/.env` - Set to USE_SQLITE=true (temporary)
- ✓ `canteen_out_updated/backend/.env` - Set to USE_SQLITE=true (temporary)
- ✓ `init_tables.py` - Initialize tables in both projects
- ✓ `setup_database.py` - Setup MySQL database and tables
- ✓ `migrate_to_mysql.py` - Migrate data from SQLite to MySQL
- ✓ `debug_mysql.py` - Debug MySQL connectivity
- ✓ `verify_tables.py` - Verify database tables

---

## Alternative: Keep Using SQLite

If MySQL issues persist and you prefer to use SQLite, no action needed. The system is currently configured to use SQLite:

```
USE_SQLITE=true  (in .env files)
```

SQLite works perfectly for development and small-to-medium deployments.

---

## Quick Reference Commands

```powershell
# Check MySQL service status
Get-Service MySQL80 | Format-List

# Start MySQL (if stopped)
Start-Service MySQL80

# Test connection
python debug_mysql.py

# Initialize tables (SQLite)
python init_tables.py

# Setup MySQL
python setup_database.py

# Migrate data to MySQL
python migrate_to_mysql.py

# Verify tables
python verify_tables.py
```

---

## Support

If issues persist:
1. Check MySQL error log: `C:\ProgramData\MySQL\MySQL Server 8.0\Data\` (*.err files)
2. Verify MySQL is actually listening: `netstat -ano | findstr :3306`
3. Check Windows Firewall is not blocking MySQL
4. Run MySQL installer repair if service wonʼt start

