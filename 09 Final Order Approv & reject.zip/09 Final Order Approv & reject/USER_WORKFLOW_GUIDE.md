# User Workflow Guide

## Public User (Employee/Anyone) - Ordering Flow

### Step 1: Access Order Form
```
User visits: http://localhost:5000/order/
```

### Step 2: Fill Personal Information
```
- Full Name: John Doe
- Email: john.doe@tata.com
```

### Step 3: Fill Location & Schedule Details  
```
- Department: Production
- Shop/Location: Shop Floor A
- Delivery Date: 2024-03-15
- Required By: 14:30
```

### Step 4: Enter Shift & People Details
```
- Shift: A Shift
- Number of People: 25
```

### Step 5: Add Food Items
```
Option 1 - Use Quick Menu:
- Click "🍵 Tea" → Adds 1 cup of Tea
- Click "🍪 Biscuits" → Adds 1 packet of Biscuits
- Click "🍱 Special Lunch" → Adds 1 plate of Special Lunch

Option 2 - Add Custom Items:
- Click "+ Add Custom Item"
- Enter: "Samosa", Qty: 50, Unit: "pieces"
- Click "+ Add Custom Item"
- Enter: "Juice", Qty: 25, Unit: "bottles"
```

### Step 6: Submit Order
```
- Click "✅ Submit Order" button
- Form validates all required fields
- Shows success modal with Order ID
- Email sent to provided email address
```

### Step 7: Order Status
```
Order #1234 is now:
- Status: Pending (awaiting canteen review)
- User receives email with order details
- User can check status later if needed
```

---

## Canteen Manager - Review Flow

### Step 1: Access Dashboard
```
User visits: http://localhost:5000/canteen/login
Enters credentials
```

### Step 2: View All Orders
```
Dashboard displays all pending orders from users:
- Order ID
- User Name & Email  
- Department & Location
- Shift & People Count
- Items ordered
- Status
```

### Step 3: Review Order Details
```
Click on order to see:
- Full order information
- Itemized list with quantities
- Delivery date & time
- Department & location details
```

### Step 4: Approve Order
```
Click "Approve" button:
- Order status changes to "Approved"
- User receives email: "Your order #1234 has been approved!"
- Item statuses set to "Pending Collection"
```

### Step 5: Reject Order (if needed)
```
Click "Reject" button:
- Enter rejection reason
- Order status changes to "Rejected"
- User receives email with reason
```

### Step 6: Mark Items as Completed
```
For approved orders:
- Click item
- Mark as "Completed" when ready
- Or mark as "Rejected" if unavailable
- Partial completion allowed
```

### Step 7: Email Notifications
```
User receives emails for:
✓ Order received confirmation
✓ Order approved notification
✓ Order completed notification
✓ Item rejection (if any items unavailable)
```

---

## Data Flow

```
┌─────────────────────────────────────────┐
│ User visits /order/                     │
│ Fills form with personal info & items   │
└────────────────────┬────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────┐
│ POST /api/orders                        │
│ Backend creates order & items           │
│ Email sent to user automatically        │
└────────────────────┬────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────┐
│ Canteen Manager logs in (/canteen/)     │
│ Sees new order in dashboard             │
└────────────────────┬────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────┐
│ Manager reviews order details           │
│ Approves/Rejects order                  │
│ User gets email notification            │
└────────────────────┬────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────┐
│ Manager marks items as completed        │
│ User receives completion email          │
└─────────────────────────────────────────┘
```

---

## Database Records

### Order Record
```
{
  id: 1234,
  supervisor_name: "John Doe",           # User's name
  supervisor_email: "john@tata.com",     # User's email
  department: "Production",
  shop_name: "Shop Floor A",
  shift: "A Shift",
  people_count: 25,
  delivery_date: "2024-03-15",
  delivery_time: "14:30",
  status: "Pending",                      # Approved/Rejected/Completed
  created_at: "2024-03-09 10:00:00"
}
```

### Order Items Record
```
{
  id: 1,
  order_id: 1234,
  item_name: "Tea",
  quantity: 1,
  unit: "cups",
  status: "Pending"
}
```

---

## Email Notifications Examples

### Order Received Email
```
Subject: Order Received - Order #1234

Dear John Doe,

Your food order has been received by the canteen!

Order Details:
- Order ID: #1234
- Items: Tea (1 cups), Biscuits (1 packets), Special Lunch (1 plates)
- Department: Production
- Required By: 14:30 on 2024-03-15
- Number of People: 25

Status: Awaiting Canteen Review

You will receive email updates as your order is processed.

Thank you!
```

### Order Approved Email
```
Subject: Order Approved - Order #1234

Dear John Doe,

Great news! Your order #1234 has been approved by the canteen.

Items Status:
✓ Tea (1 cups) - Ready for collection
✓ Biscuits (1 packets) - Ready for collection
✓ Special Lunch (1 plates) - Ready for collection

Delivery Location: Shop Floor A
Date & Time: 2024-03-15 at 14:30

Thank you for ordering!
```

### Item Completion Email
```
Subject: Order Items Ready - Order #1234

Dear John Doe,

Your order items are now ready for collection!

✓ Tea - Completed
✓ Biscuits - Completed
✓ Special Lunch - Completed

Please collect from the canteen counter.

Thank you!
```
