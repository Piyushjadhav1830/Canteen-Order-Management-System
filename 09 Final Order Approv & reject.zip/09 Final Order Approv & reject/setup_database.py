#!/usr/bin/env python3
"""
setup_database.py
-----------------
Create MySQL database and tables for the canteen application.

Usage:
  python setup_database.py
"""

import mysql.connector
from mysql.connector import Error as MySQLError

def create_database_and_tables():
    """Create the canteen_db database and all required tables."""
    
    # MySQL root connection (without selecting a database)
    mysql_config = {
        'host': '127.0.0.1',
        'port': 3306,
        'user': 'root',
        'password': 'admin123',
    }
    
    print("=" * 60)
    print("  MySQL Database & Table Setup")
    print("=" * 60)
    print()
    
    try:
        # Step 1: Create database
        print("📊 Connecting to MySQL server...")
        conn = mysql.connector.connect(**mysql_config)
        cursor = conn.cursor()
        print("✓ Connected to MySQL")
        
        print("📝 Creating database 'canteen_db'...")
        cursor.execute(
            "CREATE DATABASE IF NOT EXISTS canteen_db "
            "CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
        )
        conn.commit()
        print("✓ Database created/verified")
        
        cursor.close()
        conn.close()
        
        # Step 2: Connect to the new database and create tables
        mysql_config['database'] = 'canteen_db'
        print()
        print("📊 Connecting to canteen_db...")
        conn = mysql.connector.connect(**mysql_config)
        cursor = conn.cursor()
        print("✓ Connected to canteen_db")
        
        # Create tables
        print()
        print("📋 Creating tables...")
        
        tables = [
            '''CREATE TABLE IF NOT EXISTS supervisors (
                id INT PRIMARY KEY AUTO_INCREMENT,
                name VARCHAR(255) NOT NULL,
                email VARCHAR(255) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                department VARCHAR(255),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci''',
            
            '''CREATE TABLE IF NOT EXISTS canteen_users (
                id INT PRIMARY KEY AUTO_INCREMENT,
                username VARCHAR(255) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                email VARCHAR(255),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci''',
            
            '''CREATE TABLE IF NOT EXISTS orders (
                id INT PRIMARY KEY AUTO_INCREMENT,
                supervisor_id INT,
                supervisor_name VARCHAR(255) NOT NULL,
                supervisor_email VARCHAR(255) NOT NULL,
                department VARCHAR(255) NOT NULL,
                shop_name VARCHAR(255) NOT NULL,
                shift VARCHAR(255) NOT NULL,
                people_count INT NOT NULL,
                delivery_date VARCHAR(50),
                delivery_time VARCHAR(50),
                status VARCHAR(50) DEFAULT 'Pending',
                canteen_notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci''',
            
            '''CREATE TABLE IF NOT EXISTS order_items (
                id INT PRIMARY KEY AUTO_INCREMENT,
                order_id INT NOT NULL,
                item_name VARCHAR(255) NOT NULL,
                quantity INT NOT NULL,
                unit VARCHAR(50) DEFAULT 'units',
                status VARCHAR(50) DEFAULT 'Pending',
                rejection_reason TEXT,
                KEY fk_order_id (order_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci''',
        ]
        
        for i, table_sql in enumerate(tables, 1):
            cursor.execute(table_sql)
            print(f"  {i}. Table created ✓")
        
        conn.commit()
        
        # Step 3: Seed default users
        print()
        print("👥 Seeding default users...")
        
        cursor.execute(
            "INSERT IGNORE INTO supervisors (name, email, password, department) "
            "VALUES (%s, %s, %s, %s)",
            ('Admin Supervisor', 'supervisor@tatamotors.com', 'admin123', 'General')
        )
        cursor.execute(
            "INSERT IGNORE INTO canteen_users (username, password, email) "
            "VALUES (%s, %s, %s)",
            ('canteen', 'canteen123', 'canteen@tatamotors.com')
        )
        
        conn.commit()
        print("✓ Default users seeded")
        
        cursor.close()
        conn.close()
        
        print()
        print("=" * 60)
        print("✅ Database setup completed successfully!")
        print("=" * 60)
        print()
        print("📊 Tables created:")
        print("  • supervisors")
        print("  • canteen_users")
        print("  • orders")
        print("  • order_items")
        print()
        print("👥 Default credentials:")
        print("  Supervisor: supervisor@tata.com / pass123")
        print("  Canteen User: canteen / canteen123")
        print()
        
    except MySQLError as e:
        print()
        print(f"❌ MySQL Error: {e}")
        print()
        print("Troubleshooting:")
        print("  - Ensure MySQL is running: Get-Service MySQL80")
        print("  - Verify credentials (root/admin123)")
        print("  - Check if MySQL is listening on localhost:3306")
        exit(1)
    except Exception as e:
        print()
        print(f"❌ Error: {e}")
        exit(1)

if __name__ == '__main__':
    create_database_and_tables()
