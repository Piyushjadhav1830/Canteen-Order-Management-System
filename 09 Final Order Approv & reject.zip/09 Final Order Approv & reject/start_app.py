#!/usr/bin/env python3
"""
start_app.py
-------------
Simple script to start the Tata Motors Canteen System
"""

import os
import sys
import subprocess
import webbrowser
import time

def start_app():
    """Start the Flask application and open browser"""
    print("=" * 60)
    print("  Tata Motors Canteen System")
    print("=" * 60)
    print()
    print("🚀 Starting Flask application on port 8003...")
    print()

    # Change to backend directory
    backend_dir = os.path.join(os.path.dirname(__file__), 'backend')
    os.chdir(backend_dir)

    # Start the Flask app
    try:
        # Open browser after a short delay
        def open_browser():
            time.sleep(2)
            webbrowser.open('http://localhost:8003/')
            print("🌐 Browser opened: http://localhost:8003/")
            print()
            print("📋 Available Routes:")
            print("  • Home Dashboard: http://localhost:8003/")
            print("  • Supervisor Portal: http://localhost:8003/supervisor")
            print("  • Canteen Dashboard: http://localhost:8003/canteen")
            print("  • API Endpoints: http://localhost:8003/api")
            print()
            print("🔑 Default Credentials:")
            print("  Supervisor: supervisor@tata.com / pass123")
            print("  Canteen User: canteen / canteen123")
            print()
            print("Press Ctrl+C to stop the server")

        # Start browser opener in background
        import threading
        browser_thread = threading.Thread(target=open_browser, daemon=True)
        browser_thread.start()

        # Run Flask app
        subprocess.run([sys.executable, 'app.py'], check=True)

    except KeyboardInterrupt:
        print()
        print("🛑 Server stopped by user")
    except subprocess.CalledProcessError as e:
        print(f"❌ Error starting application: {e}")
    except Exception as e:
        print(f"❌ Unexpected error: {e}")

if __name__ == '__main__':
    start_app()
