from flask import Flask, render_template, session, redirect, url_for, request, jsonify

app = Flask(__name__)
app.secret_key = 'canteen_secret_key_tata_2024'
from datetime import timedelta
app.permanent_session_lifetime = timedelta(days=7)

@app.route('/')
def index():
    if 'canteen' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'canteen' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html', user=session['canteen'])

@app.route('/orders')
def orders():
    if 'canteen' not in session:
        return redirect(url_for('login'))
    return render_template('orders.html', user=session['canteen'])

@app.route('/order/<int:order_id>')
def order_detail(order_id):
    if 'canteen' not in session:
        return redirect(url_for('login'))
    return render_template('order_detail.html', user=session['canteen'], order_id=order_id)

@app.route('/set-session', methods=['POST'])
def set_session():
    data = request.json
    session.permanent = True
    session['canteen'] = data
    return jsonify({'success': True})

@app.route('/ping')
def ping():
    if 'canteen' in session:
        session.modified = True
        return jsonify({'alive': True})
    return jsonify({'alive': False}), 401

@app.route('/logout')
def logout():
    session.pop('canteen', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(port=5001, debug=True)
