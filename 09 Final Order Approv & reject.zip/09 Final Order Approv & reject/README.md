# 🏭 Tata Motors Canteen Order Management System

## 🚀 Quick Start

### Simple Start (Recommended)
```bash
python start_app.py
```
This automatically opens your browser to the attractive home dashboard.

### Manual Start
```bash
cd backend && python app.py
```
→ **http://localhost:8003**

### Production (Gunicorn)
```bash
pip install flask flask-cors mysql-connector-python gunicorn --break-system-packages
bash start_all.sh
```

---

## 🏠 Home Dashboard

The home page now features an attractive UI with clickable navigation cards:

- **👔 Supervisor Portal** - Place orders and manage department requirements
- **🏪 Canteen Dashboard** - Manage orders and process deliveries
- **🔌 API Documentation** - Access REST API endpoints

No more manual URL typing required!

---

## 🌐 URLs (Port 8003)

| Interface | URL | Description |
|-----------|-----|-------------|
| 🏠 Home Dashboard | http://localhost:8003 | Attractive navigation hub |
| 🏢 Supervisor Portal | http://localhost:8003/supervisor | Order placement & tracking |
| 🍽️ Canteen Dashboard | http://localhost:8003/canteen | Order management |
| 📊 API Endpoints | http://localhost:8003/api | REST API access |

---

## 🔑 Default Credentials

| Role | Username / Email | Password |
|------|-----------------|----------|
| Supervisor | supervisor@tata.com | pass123 |
| Canteen | canteen | canteen123 |

---

## 📊 Database Status

**Current Setup:** SQLite (temporary while MySQL is being configured)
- **Location:** `backend/canteen.db`
- **Tables:** supervisors, canteen_users, orders, order_items
- **Data:** 21 orders with 37 items already present

**Migration to MySQL:** See `MYSQL_MIGRATION_GUIDE.md` and `MYSQL_TROUBLESHOOTING.md`

---

## Database Setup

**Local testing** — no setup needed. Uses SQLite (`backend/canteen.db`) automatically.

**Production MySQL** — create `backend/.env`:
```env
DB_HOST=your_mysql_host
DB_PORT=3306
DB_NAME=canteen_db
DB_USER=your_user
DB_PASSWORD=your_password
USE_SQLITE=false
PORT=8003
```
PORT=48000
```

**pyodbc** (optional ODBC driver):
```env
USE_PYODBC=true
DB_DRIVER=MySQL ODBC 8.0 Unicode Driver
```

---

## Production Deployment

### Environment variables
```bash
export PORT=48000
export WORKERS=4       # Gunicorn worker processes
bash start_all.sh
```

### Run with custom workers
```bash
cd backend
gunicorn -w 4 -b 0.0.0.0:48000 --timeout 120 wsgi:app
```

### systemd service (Linux server)
```ini
[Unit]
Description=Tata Canteen System
After=network.target

[Service]
User=www-data
WorkingDirectory=/opt/canteen/backend
ExecStart=gunicorn -w 4 -b 0.0.0.0:48000 --timeout 120 wsgi:app
Restart=always

[Install]
WantedBy=multi-user.target
```
