# 🏭 Tata Motors Canteen Order Management System

## 🚀 Quick Start (No MySQL needed — runs on SQLite locally)

```bash
# 1. Install dependencies
pip install flask flask-cors mysql-connector-python pyodbc --break-system-packages

# 2. Run
cd backend
python app.py
```

Open → **http://localhost:48000**

> ✅ If no MySQL credentials are set, the app automatically uses **SQLite** (`backend/canteen.db`).
> The existing `canteen.db` file already has sample data to explore.

---

## Application URLs (Port 48000)

| Interface | URL |
|-----------|-----|
| 🏠 Home / API Info | http://localhost:48000 |
| 🏢 Supervisor Portal | http://localhost:48000/supervisor |
| 🍽️ Canteen Dashboard | http://localhost:48000/canteen |
| 📊 API Stats | http://localhost:48000/api/stats |
| 📋 All Orders | http://localhost:48000/api/orders |

---

## Default Credentials

| Role | Username / Email | Password |
|------|-----------------|----------|
| Supervisor | supervisor@tata.com | pass123 |
| Canteen | canteen | canteen123 |

---

## Database Driver Selection

| Scenario | `.env` setting | Driver used |
|----------|---------------|-------------|
| Local testing / no MySQL | *(blank DB_HOST)* | **SQLite** (automatic) |
| Force SQLite | `USE_SQLITE=true` | SQLite |
| Production MySQL | Fill DB_HOST/NAME/USER/PASSWORD | mysql-connector-python |
| ODBC MySQL | + `USE_PYODBC=true` | pyodbc |

### MySQL `.env` setup (production)
Copy `backend/.env.example` → `backend/.env` and fill in:
```env
DB_HOST=your_mysql_host
DB_PORT=3306
DB_NAME=canteen_db
DB_USER=your_user
DB_PASSWORD=your_password
PORT=48000
```

---

## Run via start_all.sh

```bash
bash start_all.sh
```
