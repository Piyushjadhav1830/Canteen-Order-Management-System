import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os
from datetime import datetime

SMTP_HOST = os.environ.get('SMTP_HOST', 'smtp.gmail.com')
SMTP_PORT = int(os.environ.get('SMTP_PORT', '587'))
SMTP_USER = os.environ.get('SMTP_USER', 'pj0993401@gmail.com')
SMTP_PASS = os.environ.get('SMTP_PASS', 'jpdo npjl usux bsmp')

FROM_NAME = 'Tata Motors Canteen'
FROM_EMAIL = SMTP_USER

EMAIL_ENABLED = True
CANTEEN_HEAD_EMAIL = "piyushjadhav1830@gmail.com"


def send_email(to_email, subject, html_body):
    if not EMAIL_ENABLED:
        print(f"[EMAIL SKIPPED] To: {to_email} | Subject: {subject}")
        return True
    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = f'{FROM_NAME} <{FROM_EMAIL}>'
        msg['To'] = to_email
        msg.attach(MIMEText(html_body, 'html'))
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.ehlo()
            server.starttls()
            server.login(SMTP_USER, SMTP_PASS)
            server.sendmail(FROM_EMAIL, to_email, msg.as_string())
        print(f"[EMAIL SENT] To: {to_email} | Subject: {subject}")
        return True
    except Exception as e:
        print(f"[EMAIL FAILED] {e}")
        return False


def _base_template(body_content):
    year = datetime.now().year
    return f"""<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"></head>
<body style="margin:0;padding:0;background:#eef2fb;font-family:'Segoe UI',Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#eef2fb;padding:32px 16px;">
<tr><td align="center">
<table width="620" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 8px 40px rgba(26,86,160,0.15);max-width:620px;">
  <tr><td style="background:linear-gradient(135deg,#0a2a5e 0%,#1a56a0 50%,#2e86de 100%);padding:24px 36px;">
    <table width="100%" cellpadding="0" cellspacing="0"><tr>
      <td><div style="font-size:22px;font-weight:900;color:#ffffff;letter-spacing:1px;">TATA MOTORS</div>
          <div style="font-size:10px;color:rgba(255,255,255,0.6);letter-spacing:2.5px;text-transform:uppercase;margin-top:3px;">Canteen Management System</div></td>
      <td style="text-align:right;vertical-align:middle;">
        <div style="background:rgba(255,255,255,0.12);border:1px solid rgba(255,255,255,0.2);border-radius:50px;padding:5px 14px;display:inline-block;">
          <span style="font-size:10px;font-weight:700;color:rgba(255,255,255,0.85);text-transform:uppercase;letter-spacing:1px;">CONFIDENTIAL</span>
        </div>
      </td>
    </tr></table>
  </td></tr>
  <tr><td style="padding:36px;">{body_content}</td></tr>
  <tr><td style="background:#f8faff;border-top:1px solid #e2e8f0;padding:20px 36px;text-align:center;">
    <p style="margin:0;font-size:12px;color:#94a3b8;">&copy; {year} <strong style="color:#1a56a0;">Tata Motors Limited</strong> &nbsp;&middot;&nbsp; Canteen Management System &nbsp;&middot;&nbsp; <strong style="color:#1a56a0;">Confidential</strong></p>
    <p style="margin:6px 0 0;font-size:11px;color:#b0bec5;">This is an automated notification. Please do not reply.</p>
  </td></tr>
</table>
</td></tr></table>
</body></html>"""


def _info_row(label, value, icon=''):
    return f"""<tr>
      <td style="padding:7px 0;width:45%;vertical-align:top;">
        <span style="font-size:11px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.5px;">{icon}&nbsp;{label}</span>
      </td>
      <td style="padding:7px 0 7px 12px;vertical-align:top;">
        <span style="font-size:13px;font-weight:600;color:#1e293b;">{value}</span>
      </td>
    </tr>"""


def send_order_received(to_email, supervisor_name, order_id, department, shop_name, shift, people_count, items,
                        delivery_time=None, delivery_date=None, phone=None):
    """Sends professional new order notification to canteen head."""
    now = datetime.now()
    order_datetime = now.strftime("%d %B %Y, %I:%M %p")

    items_rows = ''
    for i, item in enumerate(items):
        bg = '#f8faff' if i % 2 == 0 else '#ffffff'
        items_rows += f"""<tr style="background:{bg};">
          <td style="padding:11px 16px;font-size:13px;font-weight:600;color:#1e293b;border-bottom:1px solid #eef2fb;">{item['name']}</td>
          <td style="padding:11px 16px;font-size:13px;color:#1a56a0;font-weight:700;text-align:center;border-bottom:1px solid #eef2fb;">{item['quantity']}</td>
          <td style="padding:11px 16px;font-size:12px;color:#64748b;border-bottom:1px solid #eef2fb;">{item.get('unit','units')}</td>
        </tr>"""

    delivery_info = f"{delivery_date} at {delivery_time}" if (delivery_date and delivery_time) else (delivery_time or "As scheduled")
    phone_info = phone if phone else "Not provided"

    body = f"""
    <div style="background:linear-gradient(135deg,#e3f2fd,#bbdefb);border:2px solid #1a56a0;border-radius:12px;padding:18px 20px;margin-bottom:28px;">
      <table width="100%" cellpadding="0" cellspacing="0"><tr>
        <td><div style="font-size:18px;font-weight:800;color:#0d2f6e;">&#128203; New Canteen Order Received</div>
            <div style="font-size:13px;color:#1a56a0;margin-top:2px;">Immediate action required &#8212; please review and confirm</div></td>
        <td style="text-align:right;vertical-align:middle;">
          <div style="background:#1a56a0;color:#fff;font-size:14px;font-weight:800;padding:6px 14px;border-radius:8px;display:inline-block;">#ORD-{order_id:04d}</div>
          <div style="font-size:10px;color:#1a56a0;margin-top:4px;">{order_datetime}</div>
        </td>
      </tr></table>
    </div>

    <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:24px;border-collapse:separate;border-spacing:10px 0;">
      <tr>
        <td width="50%" style="vertical-align:top;padding-right:8px;">
          <div style="background:#f8faff;border:1px solid #dce6f5;border-radius:12px;padding:18px 20px;">
            <div style="font-size:11px;font-weight:800;color:#1a56a0;text-transform:uppercase;letter-spacing:1px;padding-bottom:10px;border-bottom:2px solid #dce6f5;margin-bottom:12px;">&#128205; Order Details</div>
            <table cellpadding="0" cellspacing="0" width="100%">
              {_info_row('New Order From', f'<strong>{supervisor_name}</strong>', '&#128100;')}
              {_info_row('Shop / Location', shop_name, '&#127981;')}
              {_info_row('Department', department, '&#127970;')}
              {_info_row('Shift', shift, '&#128336;')}
              {_info_row('People Count', f'<strong style="color:#1a56a0;font-size:15px;">{people_count}</strong> people', '&#128101;')}
            </table>
          </div>
        </td>
        <td width="50%" style="vertical-align:top;padding-left:8px;">
          <div style="background:#f8faff;border:1px solid #dce6f5;border-radius:12px;padding:18px 20px;">
            <div style="font-size:11px;font-weight:800;color:#1a56a0;text-transform:uppercase;letter-spacing:1px;padding-bottom:10px;border-bottom:2px solid #dce6f5;margin-bottom:12px;">&#128204; Delivery &amp; Contact</div>
            <table cellpadding="0" cellspacing="0" width="100%">
              {_info_row('Order ID', f'<strong>#ORD-{order_id:04d}</strong>', '&#128278;')}
              {_info_row('Order Date &amp; Time', order_datetime, '&#128197;')}
              {_info_row('Delivery Time', delivery_info, '&#128666;')}
              {_info_row('Contact Phone', phone_info, '&#128222;')}
            </table>
          </div>
        </td>
      </tr>
    </table>

    <div style="margin-bottom:24px;">
      <div style="font-size:14px;font-weight:800;color:#1e293b;margin-bottom:12px;">&#127869; Order Items ({len(items)} items for {people_count} people)</div>
      <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;border-radius:12px;overflow:hidden;border:1px solid #dce6f5;">
        <thead><tr style="background:linear-gradient(135deg,#0f3d7a,#1a56a0);">
          <th style="padding:12px 16px;text-align:left;font-size:11px;font-weight:700;color:#fff;text-transform:uppercase;letter-spacing:0.5px;">Item Name</th>
          <th style="padding:12px 16px;text-align:center;font-size:11px;font-weight:700;color:#fff;text-transform:uppercase;letter-spacing:0.5px;">Quantity</th>
          <th style="padding:12px 16px;text-align:left;font-size:11px;font-weight:700;color:#fff;text-transform:uppercase;letter-spacing:0.5px;">Unit</th>
        </tr></thead>
        <tbody>{items_rows}</tbody>
        <tfoot><tr style="background:#eff6ff;">
          <td colspan="3" style="padding:10px 16px;font-size:12px;font-weight:700;color:#1a56a0;">
            Total: <strong>{len(items)} items</strong> &nbsp;&middot;&nbsp; For <strong>{people_count} people</strong>
          </td>
        </tr></tfoot>
      </table>
    </div>

    <div style="background:linear-gradient(135deg,#fff8e1,#fffde7);border:2px solid #f59e0b;border-radius:12px;padding:16px 20px;text-align:center;">
      <div style="font-size:15px;font-weight:800;color:#92400e;margin-bottom:4px;">&#9889; Action Required</div>
      <div style="font-size:13px;color:#b45309;">Please log into the Canteen Portal to approve or reject this order promptly.</div>
    </div>
    """

    send_email(
        CANTEEN_HEAD_EMAIL,
        f'New Order #ORD-{order_id:04d} from {supervisor_name} | {shop_name} | {shift} | {people_count} people',
        _base_template(body)
    )


def send_order_status_update(to_email, supervisor_name, order_id, status, notes, items):
    """Sends order status update (Approved/Rejected) to supervisor."""
    now = datetime.now()
    update_datetime = now.strftime("%d %B %Y, %I:%M %p")

    is_approved = status == 'Approved'
    status_color = '#059669' if is_approved else '#dc2626'
    status_bg = '#d1fae5' if is_approved else '#fee2e2'
    status_border = '#6ee7b7' if is_approved else '#fca5a5'
    status_icon = '&#9989;' if is_approved else '&#10060;'

    items_rows = ''
    for i, item in enumerate(items):
        item_status = item.get('status', status)
        s_color = '#059669' if item_status == 'Approved' else ('#dc2626' if item_status in ('Rejected', 'Cancelled') else '#d97706')
        s_bg = '#d1fae5' if item_status == 'Approved' else ('#fee2e2' if item_status in ('Rejected', 'Cancelled') else '#fef3c7')
        bg = '#f8faff' if i % 2 == 0 else '#ffffff'
        items_rows += f"""<tr style="background:{bg};">
          <td style="padding:10px 16px;font-size:13px;font-weight:600;color:#1e293b;border-bottom:1px solid #eef2fb;">{item['item_name']}</td>
          <td style="padding:10px 16px;font-size:13px;color:#1a56a0;font-weight:700;text-align:center;border-bottom:1px solid #eef2fb;">{item['quantity']} {item.get('unit','')}</td>
          <td style="padding:10px 16px;text-align:center;border-bottom:1px solid #eef2fb;">
            <span style="background:{s_bg};color:{s_color};font-size:11px;font-weight:700;padding:3px 10px;border-radius:50px;">{item_status}</span>
          </td>
        </tr>"""

    body = f"""
    <div style="background:{status_bg};border:2px solid {status_border};border-radius:12px;padding:20px 24px;margin-bottom:28px;text-align:center;">
      <div style="font-size:32px;margin-bottom:8px;">{status_icon}</div>
      <div style="font-size:22px;font-weight:900;color:{status_color};margin-bottom:4px;">Order {status}</div>
      <div style="font-size:13px;color:{status_color};opacity:0.85;">{'Your order is confirmed and being prepared.' if is_approved else 'Your order could not be fulfilled at this time.'}</div>
    </div>

    <div style="background:#f8faff;border:1px solid #dce6f5;border-radius:12px;padding:18px 20px;margin-bottom:24px;">
      <div style="font-size:11px;font-weight:800;color:#1a56a0;text-transform:uppercase;letter-spacing:1px;padding-bottom:10px;border-bottom:2px solid #dce6f5;margin-bottom:12px;">&#128203; Order Summary</div>
      <table cellpadding="0" cellspacing="0" width="100%">
        {_info_row('Hi', f'<strong>{supervisor_name}</strong>', '&#128075;')}
        {_info_row('Order ID', f'<strong>#ORD-{order_id:04d}</strong>', '&#128278;')}
        {_info_row('Status', f'<strong style="color:{status_color};">{status}</strong>', '&#128204;')}
        {_info_row('Updated At', update_datetime, '&#128336;')}
      </table>
    </div>

    <div style="margin-bottom:24px;">
      <div style="font-size:14px;font-weight:800;color:#1e293b;margin-bottom:12px;">&#127869; Item Status</div>
      <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;border-radius:12px;overflow:hidden;border:1px solid #dce6f5;">
        <thead><tr style="background:linear-gradient(135deg,#0f3d7a,#1a56a0);">
          <th style="padding:12px 16px;text-align:left;font-size:11px;font-weight:700;color:#fff;text-transform:uppercase;">Item</th>
          <th style="padding:12px 16px;text-align:center;font-size:11px;font-weight:700;color:#fff;text-transform:uppercase;">Quantity</th>
          <th style="padding:12px 16px;text-align:center;font-size:11px;font-weight:700;color:#fff;text-transform:uppercase;">Status</th>
        </tr></thead>
        <tbody>{items_rows}</tbody>
      </table>
    </div>

    {'<div style="background:#fffbeb;border:1px solid #fde68a;border-radius:12px;padding:16px 20px;margin-bottom:24px;"><div style="font-size:13px;font-weight:800;color:#92400e;margin-bottom:6px;">&#128221; Note from Canteen</div><div style="font-size:13px;color:#78350f;">' + notes + '</div></div>' if notes else ''}

    <div style="background:{'#ecfdf5' if is_approved else '#fff1f2'};border-radius:10px;padding:14px 20px;text-align:center;border:1px solid {'#a7f3d0' if is_approved else '#fecdd3'};">
      <div style="font-size:13px;color:{'#065f46' if is_approved else '#9f1239'};">
        {'&#128640; Your order is being prepared. Please be ready at the delivery location.' if is_approved else '&#128222; For queries, please contact your canteen.'}
      </div>
    </div>
    """

    send_email(
        to_email,
        f'Order #{order_id:04d} {status} — Tata Motors Canteen',
        _base_template(body)
    )
