from flask import Flask, request, jsonify
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from database import get_db, init_db
from email_utils import send_order_received, send_order_status_update
from datetime import datetime
import threading

app = Flask(__name__)

@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    return response

@app.route('/', defaults={'path': ''}, methods=['OPTIONS'])
@app.route('/<path:path>', methods=['OPTIONS'])
def handle_options(path):
    return jsonify({}), 200

init_db()

# ================= SUPERVISOR =================

@app.route('/api/supervisor/login', methods=['POST'])
def supervisor_login():
    data = request.json
    conn = get_db()
    user = conn.execute(
        'SELECT * FROM supervisors WHERE email=? AND password=?',
        (data.get('email'), data.get('password'))
    ).fetchone()
    conn.close()

    if user:
        return jsonify({
            'success': True,
            'id': user['id'],
            'name': user['name'],
            'email': user['email'],
            'department': user['department']
        })

    return jsonify({'success': False, 'message': 'Invalid credentials'}), 401

@app.route('/api/supervisor/register', methods=['POST'])
def supervisor_register():
    data = request.json
    conn = get_db()
    try:
        conn.execute(
            'INSERT INTO supervisors (name, email, password, department) VALUES (?,?,?,?)',
            (data['name'], data['email'], data['password'], data.get('department', ''))
        )
        conn.commit()
        return jsonify({'success': True})
    except:
        return jsonify({'success': False, 'message': 'Email already exists'}), 400
    finally:
        conn.close()

# ================= CANTEEN =================

@app.route('/api/canteen/login', methods=['POST'])
def canteen_login():
    data = request.json
    conn = get_db()
    user = conn.execute(
        'SELECT * FROM canteen_users WHERE username=? AND password=?',
        (data.get('username'), data.get('password'))
    ).fetchone()
    conn.close()

    if user:
        return jsonify({
            'success': True,
            'id': user['id'],
            'username': user['username'],
            'email': user['email']
        })

    return jsonify({'success': False, 'message': 'Invalid credentials'}), 401

# ================= CREATE ORDER =================

@app.route('/api/orders', methods=['POST'])
def create_order():
    data = request.json
    conn = get_db()

    cur = conn.execute(
        '''INSERT INTO orders 
           (supervisor_id, supervisor_name, supervisor_email, department, 
            shop_name, shift, people_count, delivery_date, delivery_time) 
           VALUES (?,?,?,?,?,?,?,?,?)''',
        (
            data.get('supervisor_id'),
            data['supervisor_name'],
            data['supervisor_email'],
            data['department'],
            data['shop_name'],
            data['shift'],
            data['people_count'],
            data.get('delivery_date'),
            data.get('delivery_time')
        )
    )

    order_id = cur.lastrowid

    items = data.get('items', [])
    for item in items:
        conn.execute(
            'INSERT INTO order_items (order_id, item_name, quantity, unit) VALUES (?,?,?,?)',
            (order_id, item['name'], item['quantity'], item.get('unit', 'units'))
        )

    conn.commit()
    conn.close()

    def send_confirm():
        send_order_received(
            data['supervisor_email'],
            data['supervisor_name'],
            order_id,
            data['department'],
            data['shop_name'],
            data['shift'],
            data['people_count'],
            items
        )

    threading.Thread(target=send_confirm, daemon=True).start()

    return jsonify({'success': True, 'order_id': order_id})

# ================= GET ORDERS =================

@app.route('/api/orders', methods=['GET'])
def get_orders():
    conn = get_db()

    status = request.args.get('status')
    shift = request.args.get('shift')
    date = request.args.get('date')
    search = request.args.get('search')
    supervisor_id = request.args.get('supervisor_id')

    query = 'SELECT * FROM orders WHERE 1=1'
    params = []

    if status:
        query += ' AND status=?'
        params.append(status)

    if shift:
        query += ' AND shift=?'
        params.append(shift)

    if date:
        query += ' AND DATE(created_at)=?'
        params.append(date)

    if search:
        query += ' AND (supervisor_name LIKE ? OR department LIKE ? OR shop_name LIKE ?)'
        params += [f'%{search}%'] * 3

    if supervisor_id:
        query += ' AND supervisor_id=?'
        params.append(supervisor_id)

    query += ' ORDER BY created_at DESC'

    orders = [dict(r) for r in conn.execute(query, params).fetchall()]
    now = datetime.utcnow()

    for o in orders:
        o['items'] = [dict(i) for i in conn.execute(
            'SELECT * FROM order_items WHERE order_id=?', (o['id'],)
        ).fetchall()]

        if o['status'] == 'Pending':
            try:
                if o.get('delivery_date') and o.get('delivery_time'):
                    delivery_str = f"{o['delivery_date']} {o['delivery_time']}"
                    delivery_dt = datetime.strptime(delivery_str, "%Y-%m-%d %H:%M")

                    diff = (now - delivery_dt).total_seconds()

                    o['overdue'] = now > delivery_dt
                    o['pending_minutes'] = int(diff // 60) if diff > 0 else 0
                else:
                    o['overdue'] = False
                    o['pending_minutes'] = 0
            except:
                o['overdue'] = False
                o['pending_minutes'] = 0
        else:
            o['overdue'] = False
            o['pending_minutes'] = 0

    conn.close()
    return jsonify(orders)

# ================= GET SINGLE ORDER =================

@app.route('/api/orders/<int:order_id>', methods=['GET'])
def get_order(order_id):
    conn = get_db()

    order = conn.execute(
        'SELECT * FROM orders WHERE id=?',
        (order_id,)
    ).fetchone()

    if not order:
        return jsonify({'error': 'Not found'}), 404

    order = dict(order)

    order['items'] = [dict(i) for i in conn.execute(
        'SELECT * FROM order_items WHERE order_id=?',
        (order_id,)
    ).fetchall()]

    now = datetime.utcnow()

    if order['status'] == 'Pending':
        try:
            if order.get('delivery_date') and order.get('delivery_time'):
                delivery_str = f"{order['delivery_date']} {order['delivery_time']}"
                delivery_dt = datetime.strptime(delivery_str, "%Y-%m-%d %H:%M")

                diff = (now - delivery_dt).total_seconds()

                order['overdue'] = now > delivery_dt
                order['pending_minutes'] = int(diff // 60) if diff > 0 else 0
            else:
                order['overdue'] = False
                order['pending_minutes'] = 0
        except:
            order['overdue'] = False
            order['pending_minutes'] = 0
    else:
        order['overdue'] = False
        order['pending_minutes'] = 0

    conn.close()
    return jsonify(order)

# ================= APPROVE ORDER =================

@app.route('/api/orders/<int:order_id>/approve', methods=['POST'])
def approve_order(order_id):
    data = request.json or {}
    notes = data.get('notes', '')
    conn = get_db()

    order = conn.execute('SELECT * FROM orders WHERE id=?', (order_id,)).fetchone()
    if not order:
        conn.close()
        return jsonify({'error': 'Order not found'}), 404

    if order['status'] != 'Pending':
        conn.close()
        return jsonify({'error': 'Order is not pending'}), 400

    conn.execute(
        "UPDATE orders SET status='Approved', canteen_notes=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
        (notes, order_id)
    )
    conn.execute(
        "UPDATE order_items SET status='Approved' WHERE order_id=?",
        (order_id,)
    )
    conn.commit()

    # Fetch updated order for email
    updated = dict(conn.execute('SELECT * FROM orders WHERE id=?', (order_id,)).fetchone())
    items = [dict(i) for i in conn.execute('SELECT * FROM order_items WHERE order_id=?', (order_id,)).fetchall()]
    conn.close()

    def send_email():
        try:
            send_order_status_update(
                updated['supervisor_email'],
                updated['supervisor_name'],
                order_id,
                'Approved',
                notes,
                items
            )
        except Exception as e:
            print(f'Email error: {e}')

    threading.Thread(target=send_email, daemon=True).start()

    return jsonify({'success': True, 'status': 'Approved'})

# ================= REJECT ORDER =================

@app.route('/api/orders/<int:order_id>/reject', methods=['POST'])
def reject_order(order_id):
    data = request.json or {}
    notes = data.get('notes', '')
    conn = get_db()

    order = conn.execute('SELECT * FROM orders WHERE id=?', (order_id,)).fetchone()
    if not order:
        conn.close()
        return jsonify({'error': 'Order not found'}), 404

    if order['status'] != 'Pending':
        conn.close()
        return jsonify({'error': 'Order is not pending'}), 400

    conn.execute(
        "UPDATE orders SET status='Rejected', canteen_notes=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
        (notes, order_id)
    )
    conn.execute(
        "UPDATE order_items SET status='Rejected', rejection_reason=? WHERE order_id=?",
        (notes, order_id)
    )
    conn.commit()

    updated = dict(conn.execute('SELECT * FROM orders WHERE id=?', (order_id,)).fetchone())
    items = [dict(i) for i in conn.execute('SELECT * FROM order_items WHERE order_id=?', (order_id,)).fetchall()]
    conn.close()

    def send_email():
        try:
            send_order_status_update(
                updated['supervisor_email'],
                updated['supervisor_name'],
                order_id,
                'Rejected',
                notes,
                items
            )
        except Exception as e:
            print(f'Email error: {e}')

    threading.Thread(target=send_email, daemon=True).start()

    return jsonify({'success': True, 'status': 'Rejected'})

# ================= PARTIAL / ITEM-LEVEL REVIEW =================

@app.route('/api/orders/<int:order_id>/partial', methods=['POST'])
def partial_review(order_id):
    data = request.json or {}
    item_reviews = data.get('items', [])
    notes = data.get('notes', '')
    conn = get_db()

    order = conn.execute('SELECT * FROM orders WHERE id=?', (order_id,)).fetchone()
    if not order:
        conn.close()
        return jsonify({'error': 'Order not found'}), 404

    approved_count = 0
    cancelled_count = 0
    substituted_count = 0

    for review in item_reviews:
        item_id = review.get('id')
        status = review.get('status', 'Approved')
        reason = review.get('reason', '')
        alt_item = review.get('alt_item', '')

        # Build rejection_reason field: encode alt item for substitutions
        if status == 'Substituted' and alt_item:
            rejection_reason = f'[ALT:{alt_item}] {reason}'.strip()
        elif status in ('Cancelled', 'Rejected'):
            rejection_reason = reason
        else:
            rejection_reason = ''

        conn.execute(
            'UPDATE order_items SET status=?, rejection_reason=? WHERE id=? AND order_id=?',
            (status, rejection_reason, item_id, order_id)
        )

        if status == 'Approved':
            approved_count += 1
        elif status == 'Cancelled':
            cancelled_count += 1
        elif status == 'Substituted':
            substituted_count += 1

    # Determine overall order status
    all_items = conn.execute('SELECT status FROM order_items WHERE order_id=?', (order_id,)).fetchall()
    statuses = [r['status'] for r in all_items]

    if all(s == 'Approved' for s in statuses):
        final_status = 'Approved'
    elif all(s in ('Cancelled', 'Rejected') for s in statuses):
        final_status = 'Rejected'
    else:
        final_status = 'Approved'  # Mixed – order proceeds with available items

    conn.execute(
        'UPDATE orders SET status=?, canteen_notes=?, updated_at=CURRENT_TIMESTAMP WHERE id=?',
        (final_status, notes, order_id)
    )
    conn.commit()

    updated = dict(conn.execute('SELECT * FROM orders WHERE id=?', (order_id,)).fetchone())
    items = [dict(i) for i in conn.execute('SELECT * FROM order_items WHERE order_id=?', (order_id,)).fetchall()]
    conn.close()

    def send_email():
        try:
                send_order_status_update(
                    updated['supervisor_email'],
                    updated['supervisor_name'],
                    order_id,
                    final_status,
                    notes,
                    items
                )
        except Exception as e:
            print(f'Email error: {e}')

    threading.Thread(target=send_email, daemon=True).start()

    return jsonify({
        'success': True,
        'final_status': final_status,
        'approved': approved_count,
        'cancelled': cancelled_count,
        'substituted': substituted_count
    })

# ================= STATS =================

@app.route('/api/stats', methods=['GET'])
def get_stats():
    conn = get_db()

    total = conn.execute('SELECT COUNT(*) FROM orders').fetchone()[0]
    pending = conn.execute("SELECT COUNT(*) FROM orders WHERE status='Pending'").fetchone()[0]
    approved = conn.execute("SELECT COUNT(*) FROM orders WHERE status='Approved'").fetchone()[0]
    rejected = conn.execute("SELECT COUNT(*) FROM orders WHERE status='Rejected'").fetchone()[0]
    cancelled = conn.execute("SELECT COUNT(*) FROM orders WHERE status='Cancelled'").fetchone()[0]

    overdue = conn.execute("""
        SELECT COUNT(*) FROM orders
        WHERE status='Pending'
        AND delivery_date IS NOT NULL
        AND delivery_time IS NOT NULL
        AND datetime(delivery_date || ' ' || delivery_time) < datetime('now')
    """).fetchone()[0]

    conn.close()

    return jsonify({
        'total': total,
        'pending': pending,
        'approved': approved,
        'rejected': rejected,
        'cancelled': cancelled,
        'overdue': overdue
    })


if __name__ == '__main__':
    app.run(port=5002, debug=True)
