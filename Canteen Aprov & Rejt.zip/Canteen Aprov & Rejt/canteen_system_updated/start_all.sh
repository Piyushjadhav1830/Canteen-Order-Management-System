#!/bin/bash
# Tata Motors Canteen System - Start All Services

echo "======================================================"
echo "  TATA MOTORS CANTEEN ORDER MANAGEMENT SYSTEM"
echo "======================================================"
echo ""
echo "Installing dependencies..."
pip install flask flask-cors --break-system-packages -q

echo ""
echo "Starting Backend API on port 5002..."
cd "$(dirname "$0")/backend"
python app.py &
BACKEND_PID=$!
sleep 2

echo "Starting Supervisor App on port 5000..."
cd "$(dirname "$0")/supervisor_app"
python app.py &
SUPERVISOR_PID=$!

echo "Starting Canteen App on port 5001..."
cd "$(dirname "$0")/canteen_app"
python app.py &
CANTEEN_PID=$!

echo ""
echo "======================================================"
echo "  ALL SERVICES RUNNING!"
echo "======================================================"
echo ""
echo "  🏢 Supervisor Portal  → http://localhost:5000"
echo "     Login: supervisor@tata.com / pass123"
echo ""
echo "  🍽️  Canteen Dashboard  → http://localhost:5001"
echo "     Login: canteen / canteen123"
echo ""
echo "  ⚙️  Backend API        → http://localhost:5002"
echo ""
echo "  Press Ctrl+C to stop all services"
echo "======================================================"

wait
