#!/usr/bin/env python3
"""
clear_orders.py
---------------
Script to clear order data from the database (canteen orders and supervisor orders).
"""

import os
import sys
import sqlite3

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
BACKEND_DIR = os.path.join(CURRENT_DIR, 'backend')
DB_PATH = os.path.join(BACKEND_DIR, 'canteen.db')

if not os.path.exists(DB_PATH):
    print(f"❌ Database not found at: {DB_PATH}")
    sys.exit(1)

try:
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    print("=" * 60)
    print("  Clearing Order Data")
    print("=" * 60)
    print()
    
    # Clear order_items first (foreign key constraint)
    print("Clearing order_items...")
    cursor.execute("DELETE FROM order_items")
    order_items_count = cursor.rowcount
    
    # Clear orders
    print("Clearing orders...")
    cursor.execute("DELETE FROM orders")
    orders_count = cursor.rowcount
    
    conn.commit()
    conn.close()
    
    print()
    print("=" * 60)
    print("✅ Successfully cleared order data!")
    print("=" * 60)
    print()
    print(f"  • Deleted {orders_count} orders")
    print(f"  • Deleted {order_items_count} order items")
    print()
    
except Exception as e:
    print()
    print(f"❌ Error: {str(e)}")
    sys.exit(1)
